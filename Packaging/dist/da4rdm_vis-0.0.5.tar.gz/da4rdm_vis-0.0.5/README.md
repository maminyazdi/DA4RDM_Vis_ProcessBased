# da4rdm-vis

## Description
This package allows extracting correlations with the various phases of Research Development Life Cycle for an identified project id. The package alos allows to visuaize the comparative values for the similarity with the phases.


## Installation
The package uses Python as a programming language and utilizes basic python packages. Noteworthy, it uses few visualization pckages like plotly express and kaleido.


## Project status
The project is currently in test phase.
